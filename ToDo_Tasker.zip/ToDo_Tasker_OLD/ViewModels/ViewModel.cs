﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ToDo_Tasker.ViewModels
{
    internal class ViewModel
    {
        /// <summary>
        /// 
        /// </summary>
        private string? _Title = "ToDo-Tasker";
        public string? Title
        {
            get => _Title;
            set => _Title = value;
        }
    }
}
